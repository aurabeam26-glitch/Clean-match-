import type { Metadata } from 'next';
import { Fraunces, Inter } from 'next/font/google';
import './globals.css';

const fraunces = Fraunces({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display'
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-body'
});

export const metadata: Metadata = {
  title: 'CleanMatch — Καθαριότητα για Airbnb & καταλύματα',
  description: 'Βρες αξιόπιστο καθαριστή για σήμερα, ή δούλεψε όποτε θες.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="el">
      <body className={`${fraunces.variable} ${inter.variable} font-body`}>{children}</body>
    </html>
  );
}
