'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';

export default function OwnerDashboard() {
  const router = useRouter();
  const { role, userName, jobs } = useAppStore();

  useEffect(() => {
    if (!role) router.replace('/login?role=owner');
  }, [role, router]);

  if (!role) return null;

  const myJobs = jobs.filter((j) => j.ownerName === userName);

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-5 py-10">
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display text-2xl font-semibold text-ink">Οι αγγελίες μου</h1>
          <Link
            href="/owner/new"
            className="bg-teal hover:bg-teal-dark text-white text-sm font-medium px-4 py-2.5 rounded-seal"
          >
            + Νέα αγγελία
          </Link>
        </div>

        {myJobs.length === 0 ? (
          <div className="border border-dashed border-line rounded-2xl p-10 text-center text-ink/60">
            <p>Δεν έχεις ανεβάσει ακόμα αγγελία.</p>
            <p className="text-sm mt-1">
              Οι demo αγγελίες παρακάτω ανήκουν σε άλλους ιδιοκτήτες — για δοκιμή δημιούργησε τη δική σου.
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {myJobs.map((job) => (
              <JobCard key={job.id} job={job} viewerRole="owner" />
            ))}
          </div>
        )}

        <h2 className="font-display text-lg font-semibold text-ink mt-12 mb-4">
          Άλλες αγγελίες στην πλατφόρμα (demo)
        </h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {jobs
            .filter((j) => j.ownerName !== userName)
            .map((job) => (
              <JobCard key={job.id} job={job} viewerRole="owner" />
            ))}
        </div>
      </div>
    </main>
  );
}
