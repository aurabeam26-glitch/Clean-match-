'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAppStore } from '@/lib/store';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const roleParam = (params.get('role') as 'owner' | 'cleaner') || 'owner';
  const [role, setRoleLocal] = useState<'owner' | 'cleaner'>(roleParam);
  const [name, setName] = useState('');
  const setRole = useAppStore((s) => s.setRole);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setRole(role, name.trim());
    router.push(role === 'owner' ? '/owner/dashboard' : '/cleaner/dashboard');
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-5">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm border border-line bg-white rounded-2xl p-7"
      >
        <p className="text-xs uppercase tracking-wide text-ink/50 mb-1">Δωρεάν λογαριασμός</p>
        <h1 className="font-display text-2xl font-semibold text-ink mb-6">
          {role === 'owner' ? 'Λογαριασμός ιδιοκτήτη' : 'Λογαριασμός καθαριστή'}
        </h1>

        <div className="flex gap-2 mb-5 p-1 bg-paper rounded-seal border border-line">
          <button
            type="button"
            onClick={() => setRoleLocal('owner')}
            className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
              role === 'owner' ? 'bg-ink text-white' : 'text-ink/60'
            }`}
          >
            Ιδιοκτήτης
          </button>
          <button
            type="button"
            onClick={() => setRoleLocal('cleaner')}
            className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
              role === 'cleaner' ? 'bg-ink text-white' : 'text-ink/60'
            }`}
          >
            Καθαριστής
          </button>
        </div>

        <label className="block text-sm text-ink/70 mb-1.5" htmlFor="name">
          Όνομα ή επωνυμία
        </label>
        <input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={role === 'owner' ? 'π.χ. Villa Santorini Stays' : 'π.χ. Μαρία Κ.'}
          className="w-full border border-line rounded-xl px-3 py-2.5 mb-6 outline-none focus:ring-2 focus:ring-teal/50"
        />

        <button
          type="submit"
          className="w-full bg-teal hover:bg-teal-dark text-white font-medium py-2.5 rounded-seal transition-colors"
        >
          Συνέχεια
        </button>
        <p className="text-xs text-ink/40 mt-4 text-center">
          Demo λογαριασμός — χωρίς πραγματικό email/κωδικό σε αυτό το MVP.
        </p>
      </form>
    </main>
  );
}
