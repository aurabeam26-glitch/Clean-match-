import Link from 'next/link';
import { Seal } from '@/components/Seal';

export default function Home() {
  return (
    <main className="min-h-screen">
      <div className="max-w-5xl mx-auto px-5 pt-20 pb-16">
        <Seal label="Πληρωμή μέσω της εφαρμογής" />
        <h1 className="font-display text-4xl md:text-6xl font-semibold text-ink mt-6 leading-[1.05] max-w-3xl">
          Το κατάλυμα χρειάζεται καθαρισμό. Σήμερα.
        </h1>
        <p className="text-lg text-ink/70 mt-5 max-w-xl">
          Ανέβασε την αγγελία, ο καθαριστής την αναλαμβάνει, η πληρωμή κρατιέται
          με ασφάλεια μέχρι να ολοκληρωθεί η δουλειά. Καμία διαπραγμάτευση,
          σταθερή τιμολόγηση.
        </p>

        <div className="grid sm:grid-cols-2 gap-4 mt-10 max-w-2xl">
          <Link
            href="/login?role=owner"
            className="group border border-line bg-white rounded-2xl p-6 hover:border-teal transition-colors"
          >
            <p className="text-xs uppercase tracking-wide text-ink/50 mb-2">Έχω κατάλυμα</p>
            <p className="font-display text-xl font-semibold text-ink">
              Ανέβασε αγγελία καθαρισμού
            </p>
            <p className="text-sm text-ink/60 mt-2">Δωρεάν λογαριασμός. Πληρώνεις μόνο ανά δουλειά.</p>
            <span className="inline-block mt-4 text-teal-dark text-sm font-medium group-hover:translate-x-1 transition-transform">
              Ξεκίνα ως ιδιοκτήτης →
            </span>
          </Link>

          <Link
            href="/login?role=cleaner"
            className="group border border-line bg-white rounded-2xl p-6 hover:border-gold transition-colors"
          >
            <p className="text-xs uppercase tracking-wide text-ink/50 mb-2">Θέλω να δουλέψω</p>
            <p className="font-display text-xl font-semibold text-ink">
              Βρες δουλειές καθαρισμού κοντά σου
            </p>
            <p className="text-sm text-ink/60 mt-2">Δωρεάν λογαριασμός. Επιλέγεις πότε δουλεύεις.</p>
            <span className="inline-block mt-4 text-ink text-sm font-medium group-hover:translate-x-1 transition-transform">
              Ξεκίνα ως καθαριστής →
            </span>
          </Link>
        </div>

        <div className="mt-16 pt-10 border-t border-line grid sm:grid-cols-3 gap-8 text-sm">
          <div>
            <p className="font-display text-2xl font-semibold text-ink">01</p>
            <p className="text-ink/70 mt-1">Ο ιδιοκτήτης ανεβάζει χώρο, δωμάτια &amp; τ.μ. Η τιμή υπολογίζεται αυτόματα.</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">02</p>
            <p className="text-ink/70 mt-1">Ο καθαριστής αναλαμβάνει τη δουλειά. Η πληρωμή δεσμεύεται με ασφάλεια.</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">03</p>
            <p className="text-ink/70 mt-1">Μετά την ολοκλήρωση, η πληρωμή απελευθερώνεται στον καθαριστή.</p>
          </div>
        </div>
      </div>
    </main>
  );
}
