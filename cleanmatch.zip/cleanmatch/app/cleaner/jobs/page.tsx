'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';

export default function BrowseJobsPage() {
  const router = useRouter();
  const { role, userName, jobs, claimJob } = useAppStore();

  useEffect(() => {
    if (!role) router.replace('/login?role=cleaner');
  }, [role, router]);

  if (!role) return null;

  const openJobs = jobs.filter((j) => j.status === 'open');

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-5 py-10">
        <h1 className="font-display text-2xl font-semibold text-ink mb-1">Διαθέσιμες δουλειές</h1>
        <p className="text-sm text-ink/60 mb-8">Ανάλαβε μια δουλειά — η πληρωμή δεσμεύεται με ασφάλεια μέχρι να ολοκληρωθεί.</p>

        {openJobs.length === 0 ? (
          <div className="border border-dashed border-line rounded-2xl p-10 text-center text-ink/60">
            Δεν υπάρχουν διαθέσιμες δουλειές αυτή τη στιγμή.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {openJobs.map((job) => (
              <JobCard key={job.id} job={job} viewerRole="cleaner" onClaim={() => claimJob(job.id, userName)} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
