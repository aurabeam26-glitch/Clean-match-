'use client';

import Link from 'next/link';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';

export default function CleanerDashboard() {
  const router = useRouter();
  const { role, userName, jobs, markCompleted } = useAppStore();

  useEffect(() => {
    if (!role) router.replace('/login?role=cleaner');
  }, [role, router]);

  if (!role) return null;

  const myJobs = jobs.filter((j) => j.claimedByName === userName);
  const earnings = myJobs
    .filter((j) => j.status === 'completed' || j.status === 'paid')
    .reduce((sum, j) => sum + j.basePrice, 0);

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-5 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-2xl font-semibold text-ink">Οι δουλειές μου</h1>
            <p className="text-sm text-ink/60 mt-1">Σύνολο κερδών: €{earnings}</p>
          </div>
          <Link
            href="/cleaner/jobs"
            className="bg-teal hover:bg-teal-dark text-white text-sm font-medium px-4 py-2.5 rounded-seal"
          >
            Βρες δουλειές
          </Link>
        </div>

        {myJobs.length === 0 ? (
          <div className="border border-dashed border-line rounded-2xl p-10 text-center text-ink/60">
            Δεν έχεις αναλάβει δουλειά ακόμα.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {myJobs.map((job) => (
              <div key={job.id} className="flex flex-col gap-2">
                <JobCard job={job} viewerRole="cleaner" />
                {job.status === 'claimed' && (
                  <button
                    onClick={() => markCompleted(job.id)}
                    className="text-sm border border-line rounded-seal py-2 hover:border-teal hover:text-teal-dark transition-colors"
                  >
                    Σήμανση ως ολοκληρωμένη
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
