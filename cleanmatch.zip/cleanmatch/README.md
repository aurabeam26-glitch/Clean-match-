# CleanMatch — MVP

Marketplace δύο πλευρών: ιδιοκτήτες Airbnb/καταλυμάτων αναρτούν δουλειές
καθαρισμού μίας ημέρας, καθαριστές τις αναλαμβάνουν. Η πλατφόρμα κρατάει
προμήθεια πάνω στην τιμή.

## Τι είναι ήδη έτοιμο (frontend, mock data)
- Landing page με δύο ροές (owner / cleaner)
- Mock login (χωρίς πραγματικό auth ακόμα) με επιλογή ρόλου
- Owner: wizard ανάρτησης αγγελίας με **αυτόματο υπολογισμό τιμής**
  (βάση + ανά δωμάτιο + ανά τ.μ., βλ. `lib/pricing.ts`)
- Owner dashboard με τις αγγελίες του
- Cleaner: λίστα διαθέσιμων δουλειών, claim, dashboard με κέρδη
- Zustand store κρατάει τα πάντα in-memory (χάνεται σε refresh — φυσιολογικό για MVP)

## Τι ΔΕΝ είναι ακόμα έτοιμο (επόμενα βήματα)
1. **Πραγματικό auth** — π.χ. Clerk, Auth.js, ή Supabase Auth
2. **Πραγματική βάση δεδομένων** — π.χ. Supabase/Postgres αντί για Zustand in-memory
3. **Πραγματικές πληρωμές (escrow) — Stripe Connect**
   - Owners: `Standard` ή `Express` connected accounts όχι απαραίτητα· ο owner απλά πληρώνει με κάρτα (`PaymentIntent`)
   - Cleaners: **Stripe Connect Express account** για να λαμβάνουν payout
   - Ροή: owner πληρώνει `ownerTotal` → κρατιέται σε `PaymentIntent` με `capture_method: manual` ή μέσω `Transfer` με καθυστέρηση μέχρι `markCompleted`
   - Commission: `application_fee_amount` στο Stripe Connect κάνει ακριβώς το split που θέλεις αυτόματα
   - Χρειάζεται Stripe λογαριασμό + verified business στην Ελλάδα
4. **Πραγματικό ανέβασμα φωτογραφιών** — τώρα είναι μόνο local object URLs (χάνονται σε refresh). Θα χρειαστεί π.χ. Vercel Blob ή Supabase Storage.
5. **Ειδοποιήσεις** — email/SMS όταν μια δουλειά αναλαμβάνεται/ολοκληρώνεται
6. **Νομικά/κανονιστικά** — ως marketplace που διαχειρίζεται πληρωμές τρίτων, άξιζε λογιστική/νομική συμβουλή για ΦΠΑ, τιμολόγηση προμήθειας, και το αν χρειάζεσαι καθεστώς PSP/agent του Stripe (συνήθως όχι, αφού το Connect καλύπτει το compliance).

## Τοπική εκτέλεση (μέσω GitHub Codespaces, όπως και στο WalkIn AI)
```bash
npm install
npm run dev
```

## Deploy
Ίδια λογική με το WalkIn AI: push σε νέο repo, import στο Vercel.
