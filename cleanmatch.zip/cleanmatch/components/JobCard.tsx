import { Job } from '@/lib/types';
import { Seal } from './Seal';

const statusLabel: Record<Job['status'], string> = {
  open: 'Διαθέσιμη',
  claimed: 'Δεσμευμένη',
  completed: 'Ολοκληρώθηκε',
  paid: 'Πληρώθηκε'
};

const propertyLabel: Record<Job['propertyType'], string> = {
  apartment: 'Διαμέρισμα',
  villa: 'Βίλα',
  hotel_room: 'Δωμάτιο ξενοδοχείου',
  studio: 'Στούντιο'
};

export function JobCard({
  job,
  viewerRole,
  onClaim
}: {
  job: Job;
  viewerRole: 'owner' | 'cleaner';
  onClaim?: (jobId: string) => void;
}) {
  return (
    <div className="border border-line rounded-2xl bg-white p-5 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-semibold text-ink leading-snug">
            {job.title}
          </h3>
          <p className="text-sm text-ink/60">
            {propertyLabel[job.propertyType]} · {job.rooms} δωμ. · {job.sqm} m² · {job.city}
          </p>
        </div>
        {job.status === 'completed' || job.status === 'paid' ? (
          <Seal label={statusLabel[job.status]} />
        ) : (
          <span className="text-xs font-medium uppercase tracking-wide px-3 py-1 rounded-seal border border-line text-ink/60">
            {statusLabel[job.status]}
          </span>
        )}
      </div>

      <div className="text-sm text-ink/70">
        {new Date(job.date).toLocaleDateString('el-GR', {
          weekday: 'short',
          day: 'numeric',
          month: 'short'
        })}{' '}
        · {job.time}
        {job.claimedByName && <> · Ανέλαβε: {job.claimedByName}</>}
      </div>

      {job.notes && <p className="text-sm text-ink/70 border-l-2 border-teal/40 pl-3">{job.notes}</p>}

      <div className="flex items-end justify-between pt-2 border-t border-line">
        <div>
          {viewerRole === 'cleaner' ? (
            <p className="text-2xl font-display font-semibold text-teal-dark">
              €{job.basePrice}
            </p>
          ) : (
            <p className="text-2xl font-display font-semibold text-ink">€{job.ownerTotal}</p>
          )}
          <p className="text-xs text-ink/50">
            {viewerRole === 'cleaner' ? 'Λαμβάνεις εσύ' : `€${job.basePrice} + €${job.commission} προμήθεια`}
          </p>
        </div>

        {viewerRole === 'cleaner' && job.status === 'open' && onClaim && (
          <button
            onClick={() => onClaim(job.id)}
            className="bg-teal hover:bg-teal-dark text-white text-sm font-medium px-4 py-2 rounded-seal transition-colors"
          >
            Ανάλαβέ την
          </button>
        )}
      </div>
    </div>
  );
}
