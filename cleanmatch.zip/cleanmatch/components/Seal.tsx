export function Seal({ label }: { label: string }) {
  return (
    <span className="seal gap-1.5 border-teal text-teal px-3 py-1 text-xs font-medium tracking-wide uppercase">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M20 6L9 17l-5-5"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      {label}
    </span>
  );
}
