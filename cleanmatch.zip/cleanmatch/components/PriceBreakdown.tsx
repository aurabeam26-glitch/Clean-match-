import { PriceBreakdown as PriceBreakdownType } from '@/lib/pricing';

export function PriceBreakdown({ breakdown }: { breakdown: PriceBreakdownType }) {
  return (
    <div className="border border-line rounded-2xl bg-teal-light/50 p-5">
      <p className="text-xs uppercase tracking-wide text-ink/50 mb-3">
        Τιμή υπολογισμένη αυτόματα
      </p>
      <div className="space-y-1.5 text-sm">
        <div className="flex justify-between">
          <span className="text-ink/70">Αμοιβή καθαριστή</span>
          <span className="text-ink font-medium">€{breakdown.basePrice}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-ink/70">Προμήθεια πλατφόρμας</span>
          <span className="text-ink font-medium">€{breakdown.commission}</span>
        </div>
      </div>
      <div className="flex justify-between items-baseline pt-3 mt-3 border-t border-teal/30">
        <span className="text-ink font-medium">Εσύ πληρώνεις</span>
        <span className="font-display text-2xl font-semibold text-teal-dark">
          €{breakdown.ownerTotal}
        </span>
      </div>
    </div>
  );
}
