'use client';

import Link from 'next/link';
import { useAppStore } from '@/lib/store';

export function Header() {
  const { role, userName, setRole } = useAppStore();

  return (
    <header className="border-b border-line bg-paper/90 backdrop-blur sticky top-0 z-10">
      <div className="max-w-5xl mx-auto px-5 py-4 flex items-center justify-between">
        <Link href="/" className="font-display text-xl font-semibold tracking-tight text-ink">
          CleanMatch
        </Link>
        {role && (
          <div className="flex items-center gap-4 text-sm">
            <span className="text-ink/60">
              {role === 'owner' ? 'Ιδιοκτήτης' : 'Καθαριστής'} · {userName}
            </span>
            <button
              onClick={() => setRole(null, '')}
              className="text-ink/60 hover:text-ink underline underline-offset-2"
            >
              Αποσύνδεση
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
