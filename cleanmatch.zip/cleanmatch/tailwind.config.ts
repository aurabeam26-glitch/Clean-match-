import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#132531',
        paper: '#F6F7F5',
        teal: {
          DEFAULT: '#1E9E8C',
          dark: '#146F62',
          light: '#DCF3EF'
        },
        gold: {
          DEFAULT: '#D9A441',
          light: '#F6E7C6'
        },
        line: '#DEE3E0'
      },
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif']
      },
      borderRadius: {
        seal: '999px'
      }
    }
  },
  plugins: []
};

export default config;
