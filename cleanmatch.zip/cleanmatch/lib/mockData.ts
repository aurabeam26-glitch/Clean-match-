import { Job } from './types';
import { calculatePrice } from './pricing';

function job(partial: Omit<Job, 'basePrice' | 'commission' | 'ownerTotal'>): Job {
  const { basePrice, commission, ownerTotal } = calculatePrice(
    partial.rooms,
    partial.sqm,
    partial.propertyType
  );
  return { ...partial, basePrice, commission, ownerTotal };
}

export const seedJobs: Job[] = [
  job({
    id: 'j1',
    ownerId: 'o1',
    ownerName: 'Villa Santorini Stays',
    title: 'Καθαρισμός βίλας με πισίνα',
    city: 'Οία, Σαντορίνη',
    address: 'Οδός Ηλιοβασιλέματος 12',
    propertyType: 'villa',
    rooms: 4,
    sqm: 140,
    date: '2026-07-24',
    time: '11:00',
    notes: 'Check-out στις 11, check-in στις 16. Χρειάζεται και γύρω από την πισίνα.',
    photos: [],
    status: 'open'
  }),
  job({
    id: 'j2',
    ownerId: 'o2',
    ownerName: 'Nafplio Boutique Apts',
    title: 'Στούντιο στο κέντρο, γρήγορο turnover',
    city: 'Ναύπλιο',
    address: 'Σταϊκοπούλου 5',
    propertyType: 'studio',
    rooms: 1,
    sqm: 32,
    date: '2026-07-22',
    time: '13:00',
    notes: '',
    photos: [],
    status: 'open'
  }),
  job({
    id: 'j3',
    ownerId: 'o3',
    ownerName: 'Athens Riviera Hotel',
    title: 'Δωμάτιο ξενοδοχείου - βαθύς καθαρισμός',
    city: 'Αθήνα',
    address: 'Λεωφ. Ποσειδώνος 88',
    propertyType: 'hotel_room',
    rooms: 1,
    sqm: 24,
    date: '2026-07-21',
    time: '10:00',
    notes: 'Αλλαγή σεντονιών και πετσετών περιλαμβάνεται.',
    photos: [],
    status: 'claimed',
    claimedByName: 'Μαρία Κ.'
  }),
  job({
    id: 'j4',
    ownerId: 'o1',
    ownerName: 'Villa Santorini Stays',
    title: 'Διαμέρισμα 2 δωματίων, θέα καλντέρα',
    city: 'Φηρά, Σαντορίνη',
    address: 'Μαρινάτου 3',
    propertyType: 'apartment',
    rooms: 2,
    sqm: 65,
    date: '2026-07-23',
    time: '12:30',
    notes: '',
    photos: [],
    status: 'open'
  })
];
