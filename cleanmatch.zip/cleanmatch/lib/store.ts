'use client';

import { create } from 'zustand';
import { Job } from './types';
import { seedJobs } from './mockData';

export type Role = 'owner' | 'cleaner' | null;

interface AppState {
  role: Role;
  userName: string;
  jobs: Job[];
  setRole: (role: Role, name: string) => void;
  addJob: (job: Job) => void;
  claimJob: (jobId: string, cleanerName: string) => void;
  markCompleted: (jobId: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  role: null,
  userName: '',
  jobs: seedJobs,
  setRole: (role, name) => set({ role, userName: name }),
  addJob: (job) => set((state) => ({ jobs: [job, ...state.jobs] })),
  claimJob: (jobId, cleanerName) =>
    set((state) => ({
      jobs: state.jobs.map((j) =>
        j.id === jobId ? { ...j, status: 'claimed', claimedByName: cleanerName } : j
      )
    })),
  markCompleted: (jobId) =>
    set((state) => ({
      jobs: state.jobs.map((j) => (j.id === jobId ? { ...j, status: 'completed' } : j))
    }))
}));
