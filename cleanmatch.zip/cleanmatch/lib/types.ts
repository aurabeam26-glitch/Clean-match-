export type PropertyType = 'apartment' | 'villa' | 'hotel_room' | 'studio';

export type JobStatus = 'open' | 'claimed' | 'completed' | 'paid';

export interface Job {
  id: string;
  ownerId: string;
  ownerName: string;
  title: string;
  city: string;
  address: string;
  propertyType: PropertyType;
  rooms: number;
  sqm: number;
  date: string; // ISO date
  time: string; // e.g. "11:00"
  notes?: string;
  photos: string[];
  basePrice: number; // what the cleaner receives
  commission: number; // platform fee
  ownerTotal: number; // basePrice + commission
  status: JobStatus;
  claimedByName?: string;
}

export interface Owner {
  id: string;
  name: string;
  businessName: string;
  city: string;
}

export interface Cleaner {
  id: string;
  name: string;
  city: string;
  rating: number;
  completedJobs: number;
}
