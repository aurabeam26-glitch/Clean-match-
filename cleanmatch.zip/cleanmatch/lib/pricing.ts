import { PropertyType } from './types';

// --- Tunable pricing constants -------------------------------------------
// Base fee covers arrival, basic supplies handling, and minimum job value.
export const BASE_FEE = 15; // EUR

// Added per bedroom/room and per square meter.
export const PRICE_PER_ROOM = 6; // EUR
export const PRICE_PER_SQM = 0.15; // EUR per m²

// Multiplier applied per property type (villas/hotels take more effort).
export const PROPERTY_TYPE_MULTIPLIER: Record<PropertyType, number> = {
  studio: 1,
  apartment: 1,
  hotel_room: 0.85,
  villa: 1.2
};

// Platform commission: percentage of the base price, with a floor.
export const COMMISSION_RATE = 0.1; // 10%
export const COMMISSION_MIN = 5; // EUR minimum commission

export interface PriceBreakdown {
  basePrice: number; // paid out to the cleaner
  commission: number; // platform's cut
  ownerTotal: number; // charged to the owner
}

/**
 * Fixed formula: base + per room + per sqm, scaled by property type.
 * Rounded to the nearest whole euro for simplicity and predictability.
 */
export function calculatePrice(
  rooms: number,
  sqm: number,
  propertyType: PropertyType
): PriceBreakdown {
  const multiplier = PROPERTY_TYPE_MULTIPLIER[propertyType] ?? 1;

  const raw =
    (BASE_FEE + PRICE_PER_ROOM * rooms + PRICE_PER_SQM * sqm) * multiplier;

  const basePrice = Math.round(raw);
  const commission = Math.max(COMMISSION_MIN, Math.round(basePrice * COMMISSION_RATE));
  const ownerTotal = basePrice + commission;

  return { basePrice, commission, ownerTotal };
}
