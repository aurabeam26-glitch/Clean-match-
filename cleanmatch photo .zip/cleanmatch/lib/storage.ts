import { supabase } from './supabaseClient';

const BUCKET = 'job-photos';

/**
 * Uploads a single photo to Supabase Storage under the owner's own folder
 * and returns its public URL (bucket is public, so the URL works directly
 * as an <img src>).
 */
export async function uploadJobPhoto(file: File, ownerId: string): Promise<string> {
  const ext = file.name.split('.').pop() || 'jpg';
  const path = `${ownerId}/${crypto.randomUUID()}.${ext}`;

  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: '3600',
    upsert: false
  });

  if (error) throw new Error(error.message);

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}
