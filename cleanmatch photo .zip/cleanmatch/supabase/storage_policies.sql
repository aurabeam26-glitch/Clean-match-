-- Storage policies for the "job-photos" bucket.
-- Run this AFTER creating the bucket in the Supabase dashboard:
--   Storage -> New bucket -> name: job-photos -> Public bucket: ON -> Create bucket
-- Then paste this into SQL Editor -> Run.

-- Anyone can view/download photos (bucket is public, but the storage.objects
-- table itself still needs a SELECT policy for the public URL to resolve).
create policy "Public read for job-photos"
  on storage.objects for select
  using (bucket_id = 'job-photos');

-- Any signed-in user (owner posting a listing) can upload into job-photos.
create policy "Authenticated upload to job-photos"
  on storage.objects for insert
  with check (bucket_id = 'job-photos' and auth.role() = 'authenticated');
