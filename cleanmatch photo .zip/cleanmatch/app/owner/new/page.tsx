'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { createJob } from '@/lib/jobs';
import { uploadJobPhoto } from '@/lib/storage';
import { Header } from '@/components/Header';
import { PriceBreakdown } from '@/components/PriceBreakdown';
import { calculatePrice } from '@/lib/pricing';
import { PropertyType } from '@/lib/types';

const propertyOptions: { value: PropertyType; label: string }[] = [
  { value: 'studio', label: 'Στούντιο' },
  { value: 'apartment', label: 'Διαμέρισμα' },
  { value: 'villa', label: 'Βίλα' },
  { value: 'hotel_room', label: 'Δωμάτιο ξενοδοχείου' }
];

export default function NewJobPage() {
  const router = useRouter();
  const { profile, loading } = useAppStore();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!loading && !profile) router.replace('/login?role=owner');
  }, [loading, profile, router]);

  const [title, setTitle] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [propertyType, setPropertyType] = useState<PropertyType>('apartment');
  const [rooms, setRooms] = useState(2);
  const [sqm, setSqm] = useState(60);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('11:00');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploadingCount, setUploadingCount] = useState(0);
  const [photoError, setPhotoError] = useState('');

  const breakdown = useMemo(() => calculatePrice(rooms, sqm, propertyType), [rooms, sqm, propertyType]);

  async function handlePhotoPick(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []).slice(0, 6 - photos.length);
    if (files.length === 0 || !profile) return;

    setPhotoError('');
    setUploadingCount(files.length);

    try {
      const uploaded = await Promise.all(files.map((f) => uploadJobPhoto(f, profile.id)));
      setPhotos((prev) => [...prev, ...uploaded].slice(0, 6));
    } catch (err) {
      setPhotoError(err instanceof Error ? err.message : 'Το ανέβασμα απέτυχε.');
    } finally {
      setUploadingCount(0);
      e.target.value = '';
    }
  }

  function removePhoto(url: string) {
    setPhotos((prev) => prev.filter((p) => p !== url));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title || !city || !address || !date || !profile) return;

    setSubmitting(true);
    setError('');
    try {
      await createJob({
        ownerId: profile.id,
        ownerName: profile.name,
        title,
        city,
        address,
        propertyType,
        rooms,
        sqm,
        date,
        time,
        notes,
        photos
      });
      router.push('/owner/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Κάτι πήγε στραβά.');
      setSubmitting(false);
    }
  }

  if (loading || !profile) return null;

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-2xl mx-auto px-5 py-10">
        <h1 className="font-display text-2xl font-semibold text-ink mb-1">Νέα αγγελία καθαρισμού</h1>
        <p className="text-sm text-ink/60 mb-8">
          Η τιμή καθορίζεται αυτόματα από δωμάτια &amp; τετραγωνικά — δεν διαπραγματεύεσαι.
        </p>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm text-ink/70 mb-1.5">Τίτλος αγγελίας</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="π.χ. Καθαρισμός διαμερίσματος μετά από check-out"
              className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Πόλη / περιοχή</label>
              <input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="π.χ. Αθήνα"
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Διεύθυνση</label>
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Οδός &amp; αριθμός"
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-ink/70 mb-1.5">Τύπος καταλύματος</label>
            <div className="grid grid-cols-4 gap-2">
              {propertyOptions.map((opt) => (
                <button
                  type="button"
                  key={opt.value}
                  onClick={() => setPropertyType(opt.value)}
                  className={`text-xs py-2 rounded-xl border transition-colors ${
                    propertyType === opt.value
                      ? 'bg-ink text-white border-ink'
                      : 'border-line text-ink/60'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Δωμάτια</label>
              <input
                type="number"
                min={1}
                value={rooms}
                onChange={(e) => setRooms(Number(e.target.value))}
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Τετραγωνικά (m²)</label>
              <input
                type="number"
                min={10}
                value={sqm}
                onChange={(e) => setSqm(Number(e.target.value))}
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Ημερομηνία</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
            <div>
              <label className="block text-sm text-ink/70 mb-1.5">Ώρα</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-ink/70 mb-1.5">Φωτογραφίες χώρου</label>
            <input
              type="file"
              accept="image/*"
              multiple
              disabled={uploadingCount > 0 || photos.length >= 6}
              onChange={handlePhotoPick}
              className="text-sm"
            />
            {uploadingCount > 0 && (
              <p className="text-xs text-teal-dark mt-2">Ανέβασμα {uploadingCount} φωτογραφιών…</p>
            )}
            {photoError && <p className="text-xs text-red-600 mt-2">{photoError}</p>}
            {photos.length > 0 && (
              <div className="flex gap-2 mt-3 flex-wrap">
                {photos.map((src) => (
                  <div key={src} className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={src}
                      alt=""
                      className="w-16 h-16 object-cover rounded-lg border border-line"
                    />
                    <button
                      type="button"
                      onClick={() => removePhoto(src)}
                      className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-ink text-white text-xs flex items-center justify-center"
                      aria-label="Αφαίρεση φωτογραφίας"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm text-ink/70 mb-1.5">Σημειώσεις (προαιρετικό)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="π.χ. κωδικός εισόδου, ειδικές οδηγίες"
              className="w-full border border-line rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-teal/50"
            />
          </div>

          <PriceBreakdown breakdown={breakdown} />

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={submitting || uploadingCount > 0}
            className="w-full bg-teal hover:bg-teal-dark disabled:opacity-60 text-white font-medium py-3 rounded-seal transition-colors"
          >
            {submitting ? 'Δημοσίευση…' : 'Δημοσίευση αγγελίας'}
          </button>
        </form>
      </div>
    </main>
  );
}
