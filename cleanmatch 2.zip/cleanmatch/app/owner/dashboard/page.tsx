'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import { fetchAllJobs } from '@/lib/jobs';
import { Job } from '@/lib/types';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';

export default function OwnerDashboard() {
  const router = useRouter();
  const { profile, loading } = useAppStore();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!loading && !profile) router.replace('/login?role=owner');
  }, [loading, profile, router]);

  useEffect(() => {
    if (!profile) return;
    fetchAllJobs()
      .then(setJobs)
      .catch((e) => setError(e.message))
      .finally(() => setLoadingJobs(false));
  }, [profile]);

  if (loading || !profile) return null;

  const myJobs = jobs.filter((j) => j.ownerId === profile.id);
  const otherJobs = jobs.filter((j) => j.ownerId !== profile.id);

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-5 py-10">
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display text-2xl font-semibold text-ink">Οι αγγελίες μου</h1>
          <Link
            href="/owner/new"
            className="bg-teal hover:bg-teal-dark text-white text-sm font-medium px-4 py-2.5 rounded-seal"
          >
            + Νέα αγγελία
          </Link>
        </div>

        {error && <p className="text-sm text-red-600 mb-4">{error}</p>}
        {loadingJobs && <p className="text-sm text-ink/50">Φόρτωση…</p>}

        {!loadingJobs && myJobs.length === 0 ? (
          <div className="border border-dashed border-line rounded-2xl p-10 text-center text-ink/60">
            <p>Δεν έχεις ανεβάσει ακόμα αγγελία.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {myJobs.map((job) => (
              <JobCard key={job.id} job={job} viewerRole="owner" />
            ))}
          </div>
        )}

        {otherJobs.length > 0 && (
          <>
            <h2 className="font-display text-lg font-semibold text-ink mt-12 mb-4">
              Άλλες αγγελίες στην πλατφόρμα
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {otherJobs.map((job) => (
                <JobCard key={job.id} job={job} viewerRole="owner" />
              ))}
            </div>
          </>
        )}
      </div>
    </main>
  );
}
