'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { signUp, signIn } from '@/lib/auth';
import { useAppStore } from '@/lib/store';

type Mode = 'signup' | 'login';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const roleParam = (params.get('role') as 'owner' | 'cleaner') || 'owner';

  const [mode, setMode] = useState<Mode>('signup');
  const [role, setRole] = useState<'owner' | 'cleaner'>(roleParam);
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const setProfile = useAppStore((s) => s.setProfile);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const result =
      mode === 'signup'
        ? await signUp(email, password, role, name, city)
        : await signIn(email, password);

    setSubmitting(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    setProfile(result.profile ?? null);
    router.push(result.profile?.role === 'cleaner' ? '/cleaner/dashboard' : '/owner/dashboard');
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-5">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm border border-line bg-white rounded-2xl p-7"
      >
        <div className="flex gap-2 mb-6 p-1 bg-paper rounded-seal border border-line">
          <button
            type="button"
            onClick={() => setMode('signup')}
            className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
              mode === 'signup' ? 'bg-teal text-white' : 'text-ink/60'
            }`}
          >
            Εγγραφή
          </button>
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
              mode === 'login' ? 'bg-teal text-white' : 'text-ink/60'
            }`}
          >
            Σύνδεση
          </button>
        </div>

        <h1 className="font-display text-2xl font-semibold text-ink mb-5">
          {mode === 'signup'
            ? role === 'owner'
              ? 'Λογαριασμός ιδιοκτήτη'
              : 'Λογαριασμός καθαριστή'
            : 'Καλώς ήρθες πίσω'}
        </h1>

        {mode === 'signup' && (
          <div className="flex gap-2 mb-5 p-1 bg-paper rounded-seal border border-line">
            <button
              type="button"
              onClick={() => setRole('owner')}
              className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
                role === 'owner' ? 'bg-ink text-white' : 'text-ink/60'
              }`}
            >
              Ιδιοκτήτης
            </button>
            <button
              type="button"
              onClick={() => setRole('cleaner')}
              className={`flex-1 text-sm py-2 rounded-seal transition-colors ${
                role === 'cleaner' ? 'bg-ink text-white' : 'text-ink/60'
              }`}
            >
              Καθαριστής
            </button>
          </div>
        )}

        {mode === 'signup' && (
          <>
            <label className="block text-sm text-ink/70 mb-1.5" htmlFor="name">
              Όνομα ή επωνυμία
            </label>
            <input
              id="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={role === 'owner' ? 'π.χ. Villa Santorini Stays' : 'π.χ. Μαρία Κ.'}
              className="w-full border border-line rounded-xl px-3 py-2.5 mb-4 outline-none focus:ring-2 focus:ring-teal/50"
            />
            <label className="block text-sm text-ink/70 mb-1.5" htmlFor="city">
              Πόλη
            </label>
            <input
              id="city"
              required
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="π.χ. Αθήνα"
              className="w-full border border-line rounded-xl px-3 py-2.5 mb-4 outline-none focus:ring-2 focus:ring-teal/50"
            />
          </>
        )}

        <label className="block text-sm text-ink/70 mb-1.5" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-line rounded-xl px-3 py-2.5 mb-4 outline-none focus:ring-2 focus:ring-teal/50"
        />

        <label className="block text-sm text-ink/70 mb-1.5" htmlFor="password">
          Κωδικός
        </label>
        <input
          id="password"
          type="password"
          required
          minLength={6}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-line rounded-xl px-3 py-2.5 mb-2 outline-none focus:ring-2 focus:ring-teal/50"
        />

        {error && <p className="text-sm text-red-600 mt-2 mb-2">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-teal hover:bg-teal-dark disabled:opacity-60 text-white font-medium py-2.5 rounded-seal transition-colors mt-4"
        >
          {submitting ? 'Μια στιγμή…' : mode === 'signup' ? 'Δημιουργία λογαριασμού' : 'Σύνδεση'}
        </button>
      </form>
    </main>
  );
}
