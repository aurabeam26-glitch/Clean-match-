'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { fetchAllJobs, claimJob } from '@/lib/jobs';
import { Job } from '@/lib/types';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';

export default function BrowseJobsPage() {
  const router = useRouter();
  const { profile, loading } = useAppStore();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!loading && !profile) router.replace('/login?role=cleaner');
  }, [loading, profile, router]);

  function loadJobs() {
    fetchAllJobs()
      .then(setJobs)
      .catch((e) => setError(e.message))
      .finally(() => setLoadingJobs(false));
  }

  useEffect(() => {
    if (profile) loadJobs();
  }, [profile]);

  async function handleClaim(jobId: string) {
    if (!profile) return;
    try {
      await claimJob(jobId, profile.id, profile.name);
      loadJobs();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Κάτι πήγε στραβά.');
    }
  }

  if (loading || !profile) return null;

  const openJobs = jobs.filter((j) => j.status === 'open');

  return (
    <main className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-5 py-10">
        <h1 className="font-display text-2xl font-semibold text-ink mb-1">Διαθέσιμες δουλειές</h1>
        <p className="text-sm text-ink/60 mb-8">
          Ανάλαβε μια δουλειά — η πληρωμή δεσμεύεται με ασφάλεια μέχρι να ολοκληρωθεί.
        </p>

        {error && <p className="text-sm text-red-600 mb-4">{error}</p>}
        {loadingJobs && <p className="text-sm text-ink/50">Φόρτωση…</p>}

        {!loadingJobs && openJobs.length === 0 ? (
          <div className="border border-dashed border-line rounded-2xl p-10 text-center text-ink/60">
            Δεν υπάρχουν διαθέσιμες δουλειές αυτή τη στιγμή.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {openJobs.map((job) => (
              <JobCard key={job.id} job={job} viewerRole="cleaner" onClaim={handleClaim} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
