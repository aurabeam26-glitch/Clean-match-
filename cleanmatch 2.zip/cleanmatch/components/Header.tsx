'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { signOut } from '@/lib/auth';

export function Header() {
  const router = useRouter();
  const { profile, setProfile } = useAppStore();

  async function handleSignOut() {
    await signOut();
    setProfile(null);
    router.push('/');
  }

  return (
    <header className="border-b border-line bg-paper/90 backdrop-blur sticky top-0 z-10">
      <div className="max-w-5xl mx-auto px-5 py-4 flex items-center justify-between">
        <Link href="/" className="font-display text-xl font-semibold tracking-tight text-ink">
          CleanMatch
        </Link>
        {profile && (
          <div className="flex items-center gap-4 text-sm">
            <span className="text-ink/60">
              {profile.role === 'owner' ? 'Ιδιοκτήτης' : 'Καθαριστής'} · {profile.name}
            </span>
            <button
              onClick={handleSignOut}
              className="text-ink/60 hover:text-ink underline underline-offset-2"
            >
              Αποσύνδεση
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
