'use client';

import { useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAppStore } from '@/lib/store';
import { getCurrentProfile } from '@/lib/auth';

export function AuthListener() {
  const setProfile = useAppStore((s) => s.setProfile);
  const setLoading = useAppStore((s) => s.setLoading);

  useEffect(() => {
    getCurrentProfile()
      .then(setProfile)
      .finally(() => setLoading(false));

    const { data: listener } = supabase.auth.onAuthStateChange(async () => {
      const profile = await getCurrentProfile();
      setProfile(profile);
    });

    return () => listener.subscription.unsubscribe();
  }, [setProfile, setLoading]);

  return null;
}
