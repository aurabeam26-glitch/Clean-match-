import { supabase } from './supabaseClient';
import { Profile } from './types';

export async function signUp(
  email: string,
  password: string,
  role: 'owner' | 'cleaner',
  name: string,
  city: string
): Promise<{ profile?: Profile; error?: string }> {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) return { error: error.message };
  if (!data.user) {
    return {
      error:
        'Ο λογαριασμός δημιουργήθηκε αλλά χρειάζεται επιβεβαίωση email. Απενεργοποίησε το "Confirm email" στο Supabase (Authentication → Providers → Email) για το MVP.'
    };
  }

  const { error: profileError } = await supabase.from('profiles').insert({
    id: data.user.id,
    role,
    name,
    city
  });
  if (profileError) return { error: profileError.message };

  return { profile: { id: data.user.id, role, name, city } };
}

export async function signIn(
  email: string,
  password: string
): Promise<{ profile?: Profile; error?: string }> {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { error: error.message };
  if (!data.user) return { error: 'Κάτι πήγε στραβά κατά τη σύνδεση.' };

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', data.user.id)
    .single();

  if (profileError) return { error: 'Δεν βρέθηκε προφίλ για αυτόν τον λογαριασμό.' };

  return { profile: profile as Profile };
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function getCurrentProfile(): Promise<Profile | null> {
  const { data: sessionData } = await supabase.auth.getSession();
  const user = sessionData.session?.user;
  if (!user) return null;

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  return (profile as Profile) ?? null;
}
