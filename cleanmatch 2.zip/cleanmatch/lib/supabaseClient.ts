import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  // Loud in dev so a missing .env.local is obvious instead of a silent 401 later.
  console.warn(
    'Λείπουν τα NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY — έλεγξε το .env.local'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
