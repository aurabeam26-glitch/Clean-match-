export type PropertyType = 'apartment' | 'villa' | 'hotel_room' | 'studio';

export type JobStatus = 'open' | 'claimed' | 'completed' | 'paid';

export interface Job {
  id: string;
  ownerId: string;
  ownerName: string;
  title: string;
  city: string;
  address: string;
  propertyType: PropertyType;
  rooms: number;
  sqm: number;
  date: string; // ISO date
  time: string; // e.g. "11:00"
  notes?: string;
  photos: string[];
  basePrice: number; // what the cleaner receives
  commission: number; // platform fee
  ownerTotal: number; // basePrice + commission
  status: JobStatus;
  claimedBy?: string;
  claimedByName?: string;
}

export interface Owner {
  id: string;
  name: string;
  businessName: string;
  city: string;
}

export interface Cleaner {
  id: string;
  name: string;
  city: string;
  rating: number;
  completedJobs: number;
}

export interface Profile {
  id: string;
  role: 'owner' | 'cleaner';
  name: string;
  city: string | null;
}

// Shape of a row as it comes back from the `jobs` table (snake_case).
export interface JobRow {
  id: string;
  owner_id: string;
  owner_name: string;
  title: string;
  city: string;
  address: string;
  property_type: PropertyType;
  rooms: number;
  sqm: number;
  date: string;
  time: string;
  notes: string | null;
  photos: string[];
  base_price: number;
  commission: number;
  owner_total: number;
  status: JobStatus;
  claimed_by: string | null;
  claimed_by_name: string | null;
}

export function jobFromRow(row: JobRow): Job {
  return {
    id: row.id,
    ownerId: row.owner_id,
    ownerName: row.owner_name,
    title: row.title,
    city: row.city,
    address: row.address,
    propertyType: row.property_type,
    rooms: row.rooms,
    sqm: row.sqm,
    date: row.date,
    time: row.time,
    notes: row.notes ?? undefined,
    photos: row.photos ?? [],
    basePrice: row.base_price,
    commission: row.commission,
    ownerTotal: row.owner_total,
    status: row.status,
    claimedBy: row.claimed_by ?? undefined,
    claimedByName: row.claimed_by_name ?? undefined
  };
}
