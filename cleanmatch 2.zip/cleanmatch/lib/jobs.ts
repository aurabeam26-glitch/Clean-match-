import { supabase } from './supabaseClient';
import { Job, JobRow, jobFromRow, PropertyType } from './types';
import { calculatePrice } from './pricing';

export async function fetchAllJobs(): Promise<Job[]> {
  const { data, error } = await supabase
    .from('jobs')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data as JobRow[]).map(jobFromRow);
}

export interface NewJobInput {
  ownerId: string;
  ownerName: string;
  title: string;
  city: string;
  address: string;
  propertyType: PropertyType;
  rooms: number;
  sqm: number;
  date: string;
  time: string;
  notes: string;
  photos: string[];
}

export async function createJob(input: NewJobInput): Promise<Job> {
  const { basePrice, commission, ownerTotal } = calculatePrice(
    input.rooms,
    input.sqm,
    input.propertyType
  );

  const { data, error } = await supabase
    .from('jobs')
    .insert({
      owner_id: input.ownerId,
      owner_name: input.ownerName,
      title: input.title,
      city: input.city,
      address: input.address,
      property_type: input.propertyType,
      rooms: input.rooms,
      sqm: input.sqm,
      date: input.date,
      time: input.time,
      notes: input.notes || null,
      photos: input.photos,
      base_price: basePrice,
      commission,
      owner_total: ownerTotal,
      status: 'open'
    })
    .select('*')
    .single();

  if (error) throw new Error(error.message);
  return jobFromRow(data as JobRow);
}

export async function claimJob(jobId: string, cleanerId: string, cleanerName: string): Promise<void> {
  const { error } = await supabase
    .from('jobs')
    .update({ status: 'claimed', claimed_by: cleanerId, claimed_by_name: cleanerName })
    .eq('id', jobId)
    .eq('status', 'open'); // prevents two cleaners claiming the same job in a race

  if (error) throw new Error(error.message);
}

export async function markJobCompleted(jobId: string): Promise<void> {
  const { error } = await supabase.from('jobs').update({ status: 'completed' }).eq('id', jobId);
  if (error) throw new Error(error.message);
}
