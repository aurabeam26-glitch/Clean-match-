-- CleanMatch database schema
-- Run this in Supabase: left menu -> SQL Editor -> New query -> paste -> Run

-- Extension for gen_random_uuid()
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- PROFILES (one row per signed-up user, owner or cleaner)
-- ---------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('owner', 'cleaner')),
  name text not null,
  city text,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Profiles are publicly readable"
  on profiles for select
  using (true);

create policy "Users can insert their own profile"
  on profiles for insert
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  using (auth.uid() = id);

-- ---------------------------------------------------------------------------
-- JOBS (cleaning listings)
-- ---------------------------------------------------------------------------
create table jobs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  owner_name text not null,
  title text not null,
  city text not null,
  address text not null,
  property_type text not null check (property_type in ('apartment', 'villa', 'hotel_room', 'studio')),
  rooms int not null,
  sqm int not null,
  date date not null,
  time text not null,
  notes text,
  photos text[] not null default '{}',
  base_price numeric not null,
  commission numeric not null,
  owner_total numeric not null,
  status text not null default 'open' check (status in ('open', 'claimed', 'completed', 'paid')),
  claimed_by uuid references profiles(id),
  claimed_by_name text,
  created_at timestamptz not null default now()
);

alter table jobs enable row level security;

create policy "Jobs are publicly readable"
  on jobs for select
  using (true);

create policy "Owners can insert their own jobs"
  on jobs for insert
  with check (auth.uid() = owner_id);

-- MVP-simple update policy: any signed-in user can update a job
-- (covers a cleaner claiming an open job, or an owner/cleaner marking it done).
-- Tighten this later with separate policies per role once flows are stable.
create policy "Signed-in users can update jobs"
  on jobs for update
  using (auth.uid() is not null);
